var searchData=
[
  ['u32currentvalue_0',['u32currentvalue',['../group__vidio.html#ga64a730602dded7409fd25be661f5e619',1,'_NVDRS_SETTING_V1::u32CurrentValue'],['../group__vidio.html#gab71ef80af10ca3acb2ddb1ee99a5ce58',1,'_NVDRS_SETTING_V1::@72::u32CurrentValue']]],
  ['u32defaultvalue_1',['u32defaultvalue',['../group__vidio.html#ga9145138952a708b3f8d6207310a589e7',1,'_NVDRS_SETTING_VALUES::u32DefaultValue'],['../group__vidio.html#ga33148fb007240a5eb33f6ee55bc642b5',1,'_NVDRS_SETTING_VALUES::@67::u32DefaultValue']]],
  ['u32predefinedvalue_2',['u32predefinedvalue',['../group__vidio.html#ga549a2a24058eb9ef76f90a99d07ebe30',1,'_NVDRS_SETTING_V1::u32PredefinedValue'],['../group__vidio.html#gad2268c13c16f3757cb9953f3fe191990',1,'_NVDRS_SETTING_V1::@70::u32PredefinedValue']]],
  ['u32value_3',['u32value',['../group__vidio.html#ga644707e439359e17bfbc19e8a855b5d9',1,'_NVDRS_SETTING_VALUES::u32Value'],['../group__vidio.html#gadb8abec50871087a3963766a1c84fd8a',1,'_NVDRS_SETTING_VALUES::@69::u32Value']]],
  ['ublue_4',['ublue',['../group__vidio.html#ga8a85527cc91d1df07418f8a9bf22c12d',1,'_NVVIOGAMMARAMP8::uBlue'],['../group__vidio.html#ga2bb3efbdaf3b8703ea029e7dbb454120',1,'_NVVIOGAMMARAMP10::uBlue']]],
  ['ugreen_5',['ugreen',['../group__vidio.html#gae5d4fb477badabd4df8942eb7c97986c',1,'_NVVIOGAMMARAMP8::uGreen'],['../group__vidio.html#ga8ebfa86f93a3e8955068ef86b6f68fd5',1,'_NVVIOGAMMARAMP10::uGreen']]],
  ['upoweron_6',['uPowerOn',['../group__vidio.html#gaabb94426b288a68b493792cb841d0525',1,'_NVVIOOUTPUTSTATUS']]],
  ['ured_7',['ured',['../group__vidio.html#gabe2a2ead2f6bc2fce402dc78157154ed',1,'_NVVIOGAMMARAMP8::uRed'],['../group__vidio.html#ga57c691dbd35501b1d0e70b4ee690e6ac',1,'_NVVIOGAMMARAMP10::uRed']]],
  ['userfriendlyname_8',['userfriendlyname',['../group__vidio.html#ga33e0a8547bd9d409703e7f5065bb6a9a',1,'_NVDRS_APPLICATION_V1::userFriendlyName'],['../group__vidio.html#ga3cfdea8f4eaad0f96b088e2c1101da09',1,'_NVDRS_APPLICATION_V2::userFriendlyName'],['../group__vidio.html#ga793b8e11a654c841dbb56f82f5514bc8',1,'_NVDRS_APPLICATION_V3::userFriendlyName'],['../group__vidio.html#ga0b05a3c4682445fbb0a6db55ff1866b0',1,'_NVDRS_APPLICATION_V4::userFriendlyName']]],
  ['usyncsourcelocked_9',['uSyncSourceLocked',['../group__vidio.html#ga062fd0a44ce9d5deef880c63ae4f5b7d',1,'_NVVIOOUTPUTSTATUS']]],
  ['utilid_10',['utilId',['../group__vidio.html#gabbb708323b6df9734501b6784dc615de',1,'_NV_GPU_CLIENT_UTILIZATION_DATA_V1']]],
  ['utilizationpercent_11',['utilizationPercent',['../group__vidio.html#gaf3fb95eb5f7668b730b25ca281acf474',1,'_NV_GPU_CLIENT_UTILIZATION_DATA_V1']]],
  ['utils_12',['utils',['../group__vidio.html#gac3f6831c9eea86fa269ff1f86b0f922f',1,'_NV_GPU_CLIENT_CALLBACK_UTILIZATION_DATA_V1']]]
];
