var searchData=
[
  ['zonelocation',['zoneLocation',['../group__vidio.html#gac00964088426ab7c6c80228ddcee7f24',1,'_NV_GPU_CLIENT_ILLUM_ZONE_INFO_V1']]]
];
