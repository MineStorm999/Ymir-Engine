var searchData=
[
  ['stereohandle_0',['StereoHandle',['../group__nvapihandles.html#ga1a88531978f553ee713f7ce29f2cb980',1,'nvapi_lite_common.h']]]
];
