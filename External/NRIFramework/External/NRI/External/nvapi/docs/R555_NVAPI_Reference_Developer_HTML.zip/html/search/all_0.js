var searchData=
[
  ['0_20size_20of_20buffer_20required_20for_20currently_20set_20default_20stereo_20profile_20name_20including_20trailing_200_0',['!=0 - size of buffer required for currently set default stereo profile name including trailing &apos;0&apos;.',['../group__stereoapi.html#autotoc_md1',1,'']]],
  ['0_20there_20is_20no_20default_20stereo_20profile_20name_20currently_20set_1',['==0 - there is no default stereo profile name currently set',['../group__stereoapi.html#autotoc_md0',1,'']]]
];
